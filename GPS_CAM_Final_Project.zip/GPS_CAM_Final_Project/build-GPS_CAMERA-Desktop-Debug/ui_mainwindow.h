/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *label_Preview;
    QLabel *Label_DateTime;
    QPushButton *pushButton_Open;
    QLabel *label_Captured;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QPushButton *Capture;
    QPushButton *pushButton_StartStop;
    QWidget *widget1;
    QHBoxLayout *horizontalLayout;
    QLineEdit *Latitute;
    QLineEdit *Longtitute;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(679, 531);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        label_Preview = new QLabel(centralWidget);
        label_Preview->setObjectName(QString::fromUtf8("label_Preview"));
        label_Preview->setGeometry(QRect(40, 110, 411, 271));
        Label_DateTime = new QLabel(centralWidget);
        Label_DateTime->setObjectName(QString::fromUtf8("Label_DateTime"));
        Label_DateTime->setGeometry(QRect(80, 50, 481, 22));
        pushButton_Open = new QPushButton(centralWidget);
        pushButton_Open->setObjectName(QString::fromUtf8("pushButton_Open"));
        pushButton_Open->setGeometry(QRect(530, 100, 99, 30));
        label_Captured = new QLabel(centralWidget);
        label_Captured->setObjectName(QString::fromUtf8("label_Captured"));
        label_Captured->setGeometry(QRect(517, 171, 111, 101));
        widget = new QWidget(centralWidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(530, 310, 111, 68));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        Capture = new QPushButton(widget);
        Capture->setObjectName(QString::fromUtf8("Capture"));

        verticalLayout->addWidget(Capture);

        pushButton_StartStop = new QPushButton(widget);
        pushButton_StartStop->setObjectName(QString::fromUtf8("pushButton_StartStop"));

        verticalLayout->addWidget(pushButton_StartStop);

        widget1 = new QWidget(centralWidget);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(70, 410, 381, 34));
        horizontalLayout = new QHBoxLayout(widget1);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        Latitute = new QLineEdit(widget1);
        Latitute->setObjectName(QString::fromUtf8("Latitute"));

        horizontalLayout->addWidget(Latitute);

        Longtitute = new QLineEdit(widget1);
        Longtitute->setObjectName(QString::fromUtf8("Longtitute"));

        horizontalLayout->addWidget(Longtitute);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 679, 28));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        label_Preview->setText(QApplication::translate("MainWindow", "<html><head/><body><p><br/></p></body></html>", 0, QApplication::UnicodeUTF8));
        Label_DateTime->setText(QString());
        pushButton_Open->setText(QApplication::translate("MainWindow", "Open", 0, QApplication::UnicodeUTF8));
        label_Captured->setText(QString());
        Capture->setText(QApplication::translate("MainWindow", "Capture", 0, QApplication::UnicodeUTF8));
        pushButton_StartStop->setText(QApplication::translate("MainWindow", "ON", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
