#include<mainwindow.h>
#include<QDebug>


void MainWindow::Serial_Init(void)
{
    serial.setPortName("/dev/ttyAMA0");
    serial.setBaudRate(QSerialPort::Baud4800);
    serial.setDataBits(QSerialPort::Data8);
    serial.setParity(QSerialPort::NoParity);
    serial.setStopBits(QSerialPort::OneStop);
    serial.setFlowControl(QSerialPort::NoFlowControl);
    serial.open(QIODevice::ReadWrite);
    if(serial.isOpen()==true)
    {
        qDebug()<<"The Serial port is opened...";
    }
    else
    {
        qDebug()<<"The Serial port is not opened...";
        return;
    }
}


