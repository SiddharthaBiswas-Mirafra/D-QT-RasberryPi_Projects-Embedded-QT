#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QImage>
#include<raspicam/raspicam.h>
#include<QtSerialPort/QSerialPort>
#include<QDebug>
using namespace raspicam;
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    static int WPT;
    ~MainWindow();
public:
    QSerialPort serial;
    void Serial_Init(void);
private slots:
    void on_pushButton_StartStop_clicked();
    void Image_handle(QImage &);
    void Streaming(void);
    void GPSReading(QByteArray&);
    //QPixmap img();

    void on_Capture_clicked();

    void on_pushButton_Open_clicked();

private:
    Ui::MainWindow *ui;

};

#endif // MAINWINDOW_H
