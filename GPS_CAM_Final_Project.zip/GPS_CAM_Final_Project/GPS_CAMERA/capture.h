#ifndef CAPTURE_H
#define CAPTURE_H
//#include"mainwindow.h"
#include<QPixmap>
#include<QDate>
#include<QTime>
#include<QFile>
#include<QFileDialog>
struct Frame
{
    QImage Image;
    double Lat,Longt; //Lat: Latitude and Longt: Longitude

};
QDataStream &operator<<(QDataStream &out, const Frame &f) //operator "<<" overloaded for open Image from secondary memory.
{
    out<<f.Image;
    out<<f.Lat;
    out<<f.Longt;
    return  out;
}
QDataStream &operator>>(QDataStream &in,  Frame &f) //operator ">>" overloaded for saved Image to secondary memory.
{
    in>>f.Image;
    in>>f.Lat;
    in>>f.Longt;
    return  in;
}

#endif // CAPTURE_H
