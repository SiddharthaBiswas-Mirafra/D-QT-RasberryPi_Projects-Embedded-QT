﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"capture.h"
#include<QImage>
#include<setjmp.h>
#include<unistd.h>
#include<QMessageBox>


static jmp_buf jump;
static raspicam::RaspiCam camera;
static QByteArray GPS_DATA;
static int Lat1,Longt1;
static double Lat2,Longt2;
//static MainWindow::QPixmap img();

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    Serial_Init();
    QPixmap img("../VectorIndia.jpeg");
    int wt=ui->label_Preview->width();
    int ht=ui->label_Preview->height();
    ui->label_Preview->setPixmap(img.scaled(wt,ht,Qt::KeepAspectRatio));
}

MainWindow::~MainWindow()
{
    delete ui;
    serial.close();
    qDebug()<<"The Serial port has closed....";
}

void MainWindow::on_pushButton_StartStop_clicked()
{

    if((ui->pushButton_StartStop->text())=="ON")
    {
        ui->pushButton_StartStop->setText("OFF");
        Streaming();
        //ui->label_Preview->setText("Camera is streaming");
    }
    else {

        qApp->processEvents();
            camera.release();
        ui->pushButton_StartStop->setText("ON");
        ui->label_Preview->clear();
        QPixmap img("../VectorIndia.jpeg");
        int wt=ui->label_Preview->width();
        int ht=ui->label_Preview->height();
     //   while(1)

        ui->label_Preview->setPixmap(img.scaled(wt,ht,Qt::KeepAspectRatio));
        ui->label_Captured->clear();
        ui->Latitute->clear();
        ui->Longtitute->clear();
        longjmp(jump,1);
//        QApplication::processEvents();
        //this->repaint();
       // ui->label_Preview->setPixmap(img);

    }
}

void MainWindow::GPSReading(QByteArray &GData)
{
    if(GData.contains("$GPGLL"))
        {
            QList <QByteArray> GPSDATA=GData.split(',');
            //ui->label_2->setText(GPSDATA.at(3));

            Lat1=static_cast<int>(GPSDATA.at(1).toDouble()/100);
            Lat2=(GPSDATA.at(1).toDouble()-Lat1*100)/60;
            Lat2=Lat1+Lat2;
            ui->Latitute->setText(QString::number(Lat2,'g',9));

            Longt1=static_cast<int>(GPSDATA.at(3).toDouble()/100);
            Longt2=(GPSDATA.at(3).toDouble()-Longt1*100)/60;
            Longt2=Longt1+Longt2;
            ui->Longtitute->setText(QString::number(Longt2));
            return;

        }
        if(GData.contains("$GPRMC"))
        {
            QList <QByteArray> GPSDATA=GData.split(',');
            //ui->label_2->setText(GPSDATA.at(3));

            Lat1=static_cast<int>(GPSDATA.at(3).toDouble()/100);
            Lat2=(GPSDATA.at(3).toDouble()-Lat1*100)/60;
            Lat2=Lat1+Lat2;
            ui->Latitute->setText(QString::number(Lat2,'g',9));

            Longt1=static_cast<int>(GPSDATA.at(5).toDouble()/100);
            Longt2=(GPSDATA.at(5).toDouble()-Longt1*100)/60;
            Longt2=Longt1+Longt2;
            ui->Longtitute->setText(QString::number(Longt2));
            return;

        }
        if(GData.contains("$GPGGA"))
        {
            QList <QByteArray> GPSDATA=GData.split(',');
            //ui->label_2->setText(GPSDATA.at(3));

            Lat1=static_cast<int>(GPSDATA.at(2).toDouble()/100);
            Lat2=(GPSDATA.at(2).toDouble()-Lat1*100)/60;
            Lat2=Lat1+Lat2;
            ui->Latitute->setText(QString::number(Lat2,'g',9));

            Longt1=static_cast<int>(GPSDATA.at(4).toDouble()/100);
            Longt2=(GPSDATA.at(4).toDouble()-Longt1*100)/60;
            Longt2=Longt1+Longt2;
            ui->Longtitute->setText(QString::number(Longt2));
            return;

        }
        return;
}

void MainWindow::Image_handle(QImage& img)
{
    int w=ui->label_Preview->width();
    int h=ui->label_Preview->height();
    ui->label_Preview->setPixmap(QPixmap::fromImage(img).scaled(w,h,Qt::AspectRatioMode()));
     QApplication::processEvents();
     this->repaint();

}

void MainWindow::Streaming(void)
{
    camera.open();
    int x=0;
    unsigned char * dat = new unsigned char[camera.getImageTypeSize(RASPICAM_FORMAT_RGB)];
        while(1)
        {
            camera.grab();
            camera.retrieve(dat, RASPICAM_FORMAT_RGB);

            // Convert the data and send to the caller to handle
            QImage image = QImage(dat, camera.getWidth(), camera.getHeight(), QImage::Format_RGB888);
        // ui->imgLabel->setPixmap(QPixmap::fromImage(image));
            GPS_DATA=serial.readLine();
            GPSReading(GPS_DATA);
       emit Image_handle(image);
            if((x=setjmp(jump))==1)
                break;

        }
return;
}

void MainWindow::on_Capture_clicked()
{
    if((ui->pushButton_StartStop->text())=="ON")
    {
        return;
    }

    struct Frame FRAME;
    unsigned char* picture=new unsigned char[camera.getImageTypeSize(RASPICAM_FORMAT_RGB)];
    camera.grab();
    camera.retrieve(picture,RASPICAM_FORMAT_RGB);
    FRAME.Image = QImage(picture,camera.getWidth(),camera.getHeight(),QImage::Format_RGB888);
    FRAME.Lat=Lat2;
    FRAME.Longt=Longt2;

    int w=ui->label_Captured->width();
    int h=ui->label_Captured->height();
    ui->label_Captured->setPixmap(QPixmap::fromImage(FRAME.Image).scaled(w,h,Qt::AspectRatioMode()));
    QString path="../Pics/";
    QDate d=QDate::currentDate();
    QTime t=QTime::currentTime();
    QString DateTime;
    ui->Label_DateTime->setText(DateTime);
    DateTime=path+d.toString("dd")+t.toString("HH:mm:ss")+".sidp";

    QFile file(DateTime);
    if(!file.open(QIODevice::WriteOnly))
    {
        ui->Label_DateTime->setText("File open failed");
        return;
    }
    QDataStream out(&file);
    out<<FRAME;
    //out.setVersion(QDataStream::Qt_4_8);
    //file.write((char*)&FRAME,sizeof(FRAME));
    file.close();

    //ui->Label_DateTime->setText(DateTime);

}

void MainWindow::on_pushButton_Open_clicked()
{
    QString filter="Image file(*.jpeg);;SidPixel file(*.sidp);;All files(*.*)";
        QString open_file;
        if(ui->pushButton_StartStop->text()=="ON")
            {
            if((open_file=QFileDialog::getOpenFileName(this,"Open a file","../Pics/",filter))!=NULL)
            {
                int wt=ui->label_Preview->width();
                int ht=ui->label_Preview->height();
            QString file_name=open_file;
            ui->Label_DateTime->setText(open_file);
            QFile file(file_name);
            if(!file.open(QIODevice::ReadOnly))
            {
                ui->Label_DateTime->setText("File open failed");
                return;
            }
            struct Frame FRAME;
            QDataStream in(&file);
            //file.read((char*)&FRAME,sizeof(FRAME));
            in>>FRAME;
            QImage img=FRAME.Image;
            //file.close();
            //QPixmap file(open_file);
            ui->label_Preview->setPixmap(QPixmap::fromImage(img).scaled(wt,ht,Qt::AspectRatioMode()));
            ui->Latitute->setText(QByteArray::number(FRAME.Lat,'g',9));
            ui->Longtitute->setText(QByteArray::number(FRAME.Longt,'g',9));
            //ui->label_Preview->setPixmap(img.scaled(wt,ht,Qt::KeepAspectRatio));
            //ui->label_FileName->setText(file_name);
            //file.close();
            }
            }
            else
            {
                QMessageBox::information(this,"Streaming","Turn off the streaming first.");
            }
}
